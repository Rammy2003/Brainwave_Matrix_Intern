import java.util.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ATM {
    private int pin = 1111;
    private int balance = 100000;
    private Scanner sc = new Scanner(System.in);
  
    private List<String> transactions = new ArrayList<>();
    
    private boolean authenticateUser() {
        int attempts = 0;
        while (attempts < 3) {
            System.out.print("Enter your PIN (or 0 to cancel): ");
            int userPin = sc.nextInt();
            if (userPin == 0) {
                System.out.println("Transaction canceled.");
                return false;
            }
            if (userPin == pin) {
                return true;
            } else {
                System.out.println("Invalid PIN. Try again.");
                attempts++;
            }
        }
        System.out.println("Too many incorrect attempts. Exiting...");
        return false;
    }

    public void withdraw(int withdrawl_bal) {
        if (!authenticateUser()) return;
        if (withdrawl_bal > 0 && withdrawl_bal % 100 == 0 && withdrawl_bal <= balance) {
            balance -= withdrawl_bal;
            System.out.println("Withdrawal successful. Your current balance is: " + balance);
            transactions.add("Withdrawal: " + withdrawl_bal + " on " + getCurrentTimestamp());
        } else {
            System.out.println("Invalid amount or insufficient funds.");
        }
    }

    public void deposit(int deposit_bal) {
        if (!authenticateUser()) return;
        if (deposit_bal > 0 && deposit_bal % 100 == 0) {
            balance += deposit_bal;
            System.out.println("Deposit successful. Your current balance is: " + balance);
            transactions.add("Deposit: " + deposit_bal + " on " + getCurrentTimestamp());
        } else {
            System.out.println("Enter a valid deposit amount.");
        }
    }

    public void checkBalance() {
        if (!authenticateUser()) return;
        System.out.println("Current balance: " + balance);
    }

    public void transfer() {
        System.out.print("Enter recipient account number (or 0 to cancel): ");
        String recipientAccount = sc.next();

        if (recipientAccount.equals("0")) {
            System.out.println("canceled.");
            return;
        }

        if (recipientAccount.length() < 10 || recipientAccount.length() > 18 || !recipientAccount.matches("\\d+") || isAllZeros(recipientAccount)) {
            System.out.println("Invalid account number. It must be between 10-18 digits, contain only numbers, and not be all zeros.");
            return;
        }

        System.out.print("Enter amount to transfer (or 0 to cancel): ");
        int amount = sc.nextInt();
        if (amount == 0) {
            System.out.println("Transfer canceled.");
            return;
        }

        System.out.print("Confirm transfer? (yes/no): ");
        sc.nextLine();  
        String confirmation = sc.nextLine();
        if (!confirmation.equalsIgnoreCase("yes")) {
            System.out.println("Transfer canceled.");
            return;
        }

        if (!authenticateUser()) return;

        if (amount > 0 && amount % 100 == 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Transfer successful to account " + recipientAccount + ". Your current balance is: " + balance);
            transactions.add("Transfer: " + amount + " to account " + recipientAccount + " on " + getCurrentTimestamp());
        } else {
            System.out.println("Invalid amount or insufficient funds.");
        }
    }

    public void pinChange() {
        if (!authenticateUser()) return;
        System.out.print("Enter new PIN (4 digits, or 0 to cancel): ");
        int newPin = sc.nextInt();
        if (newPin == 0) {
            System.out.println("PIN change canceled.");
            return;
        }
        if (newPin >= 1000 && newPin <= 9999) {
            pin = newPin;
            System.out.println("PIN changed successfully.");
            transactions.add("PIN changed successfully on " + getCurrentTimestamp());
        } else {
            System.out.println("Invalid PIN format.");
        }
    }

    public void miniStatement() {
        if (!authenticateUser()) return;
        System.out.println("Mini Statement:");
        if (transactions.isEmpty()) {
            System.out.println("No transactions available.");
        } else {
            for (String record : transactions) {
                System.out.println(record);
            }
        }
        System.out.println("End of Mini Statement.");
    }

    private String getCurrentTimestamp() {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return now.format(formatter);
    }

    public void exit() {
        System.out.println("Thank you for using our ATM. Have a great day!");
    }

    // Helper method to check if the account number is all zeros
    private boolean isAllZeros(String accountNumber) {
        return accountNumber.matches("^0+$");
    }

    public static void main(String[] args) {
        ATM atm = new ATM();
        Scanner sc = new Scanner(System.in);
        
        while (true) {
            System.out.println("===============================================");
            System.out.println("                 Welcome to ATM                ");
            System.out.println("===============================================");
            System.out.println("Select one of the following options:");
            System.out.println("1. Withdraw Cash");  // Take money out of your bank account.");
            System.out.println("2. Deposit Cash ");  // Add money to your account.");
            System.out.println("3. Check Balance ");  // See how much money is in your account.");
            System.out.println("4. Transfer Money ");  // Send funds to another account.");
            System.out.println("5. PIN Change ");     //Update your ATM PIN for security.");
            System.out.println("6. Mini Statement ");  // Get a quick summary of recent transactions.");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");
            
            int choice = sc.nextInt();
            if (choice == 1) {
                System.out.print("Enter withdrawal amount: ");
                int withdrawl_bal = sc.nextInt();
                if (withdrawl_bal > 0 && withdrawl_bal % 100 == 0) {
                    atm.withdraw(withdrawl_bal);
                } else {
                    System.out.println("Enter a valid withdrawal amount");
                }
            } else if (choice == 2) {
                System.out.print("Enter deposit amount: ");
                int deposit_bal = sc.nextInt();
                if (deposit_bal > 0 && deposit_bal % 100 == 0) {
                    atm.deposit(deposit_bal);
                } else {
                    System.out.println("Enter a valid deposit amount");
                }
            } else if (choice == 3) {
                atm.checkBalance();
            } else if (choice == 4) {
                atm.transfer();
            } else if (choice == 5) {
                atm.pinChange();
            } else if (choice == 6) {
                atm.miniStatement();
            } else if (choice == 7) {
                atm.exit();
                sc.close();
                break;
            } else {
                System.out.println("Invalid choice");
            }
        }
    }
}
